#ifndef PLAYER_H_
#define PLAYER_H_
//int collision(SDL_Rect* rect1,SDL_Rect* rect2);
void init_bg(SDL_Surface **image,SDL_Rect *pos);
void scrolling(SDL_Rect *camera,SDL_Event event,int*x)
#endif
