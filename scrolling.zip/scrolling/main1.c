#include <stdio.h>
#include <stdlib.h>
#include "SDL/SDL.h"
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_image.h>
int collision(SDL_Rect* rect1,SDL_Rect* rect2)
{
        if(rect1->y >= rect2->y + rect2->h)
                return 0;
        if(rect1->x >= rect2->x + rect2->w)
                return 0;
        if(rect1->y + rect1->h <= rect2->y)
                return 0;
        if(rect1->x + rect1->w <= rect2->x)
                return 0;
        return 1;
}
int main()
{SDL_Surface *screen=NULL;
SDL_Surface *image=NULL,*dr=NULL;
SDL_Rect positionecran,camera,imgloc={2000,300,250,200},posrel,location={0,0,800,600};
SDL_Event event;
int continuer=1,etat=0,b[2]={0,0};
SDL_Init(SDL_INIT_VIDEO);
int dist=0;
screen=SDL_SetVideoMode(800,600,32,SDL_SWSURFACE|SDL_RESIZABLE|SDL_DOUBLEBUF);
image=SDL_LoadBMP("nature.bmp");
dr=SDL_LoadBMP("image.bmp");
	camera.x = 0;
        camera.y = 0;
        camera.w = 800;
        camera.h = 600;
SDL_EnableKeyRepeat(40,40);
SDL_BlitSurface(image,NULL,screen,&camera);
SDL_Flip(screen);
while(continuer==1)
{               
SDL_PollEvent(&event);
switch(event.type)
	{
		case SDL_QUIT :
		{
			continuer=0;
		}break;
		case SDL_KEYDOWN:
		{switch(event.key.keysym.sym)
			{
			case SDLK_RIGHT :
			
                               b[0] = 1;break;
                        case SDLK_LEFT:
                               b[1] = 1;break;
			}
		}break;
case SDL_KEYUP:
                switch(event.key.keysym.sym)
                  {
                   case SDLK_RIGHT:
                   b[0] = 0;
                   break;
                   case SDLK_LEFT:
                   b[1] = 0;
                   break;
                    }
                    break;
	}
if(b[0])
                {	dist+=3;
                        camera.x += 3;
                        if(camera.x >= 3200)
                                {camera.x = 0;
				location.x=0;}
                }
                else if(b[1])
                {	dist -=3;
                        camera.x -= 3;
                        if(camera.x <= 0)
                                {camera.x = 3200;
				location.x=3200;}
                }
posrel.x=imgloc.x-camera.x;
posrel.y=imgloc.y-camera.y;
SDL_BlitSurface(image,&camera,screen,NULL);
if (collision(&camera,&imgloc))
SDL_BlitSurface(dr,NULL,screen,&posrel);

SDL_Flip(screen);
}

SDL_FreeSurface(dr);
SDL_FreeSurface(image);
SDL_Quit();
}

