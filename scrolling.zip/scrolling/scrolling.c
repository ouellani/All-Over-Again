#include <stdio.h>
#include <stdlib.h>
#include "SDL/SDL.h"
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_image.h>
/*int collision(SDL_Rect* rect1,SDL_Rect* rect2)
{
        if(rect1->y >= rect2->y + rect2->h)
                return 0;
        if(rect1->x >= rect2->x + rect2->w)
                return 0;
        if(rect1->y + rect1->h <= rect2->y)
                return 0;
        if(rect1->x + rect1->w <= rect2->x)
                return 0;
        return 1;
}*/
void init_bg(SDL_Surface **image,SDL_Rect *pos)
{(*image)=SDL_LoadBMP("nature.bmp");
pos->x=0;
pos->y=0;
}
void scrolling(SDL_Rect *camera,SDL_Event event,int*x)
{
int b[2]={0,0};
switch(event.type)
{case SDL_KEYDOWN:
{if (event.key.keysym.sym==SDLK_RIGHT)
{b[0] = 1;
}
else if(event.key.keysym.sym==SDLK_RIGHT)
{b[1] = 1;
}
else
{b[0] = 0;
b[1] = 0;
}
}break;
}
if(b[0])
                {
                        (*x)+=800;
                        camera->x+=5;
                        if(camera->x >= 3200)
                                camera->x = 0;
                }
                else if(b[1])
                {
                        (*x)-=800;
                        camera->x-=800;
                        if(camera->x <= 0)
                                camera->x = 3200;
                }
}
