#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "SDL/SDL.h"
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_image.h>
#include "update.h"
#include "struct.h"
void choix(int *f,int *c,SDL_Event event,char ch[10],pos *p,Mix_Music *musics)
{
if(strcmp(ch,"mm")==0)
	{
	if (((p->x)>340)&&((p->x)<480)&&((p->y)>180)&&((p->y)<220))
		{(*f)=0;
		}
	else if (((p->x)>340)&&((p->x)<480)&&((p->y)>270)&&((p->y)<320))
		{(*f)=1;
		}
	else if(((p->x)>340)&&((p->x)<480)&&((p->y)>375)&&((p->y)<425))
		{(*f)=2;
		}
	else if(((p->x)>340)&&((p->x)<480)&&((p->y)>475)&&((p->y)<525))
		{(*f)=3;
		}
	}

if(strcmp(ch,"cg")==0)
	{
	if(((p->x)>340)&&((p->x)<480)&&((p->y)>180)&&((p->y)<220))
		(*c)=0;
	else if (((p->x)>340)&&((p->x)<480)&&((p->y)>270)&&((p->y)<320))
		(*c)=1;
	else if(((p->x)>340)&&((p->x)<480)&&((p->y)>375)&&((p->y)<425))
		(*c)=2;
	else if(((p->x)>340)&&((p->x)<480)&&((p->y)>475)&&((p->y)<525))
		(*c)=3;
	else if(((p->x)>380)&&((p->x)<440)&&((p->y)>454)&&((p->y)<484))
		(*c)=4;
	else if(((p->x)>380)&&((p->x)<440)&&((p->y)>506)&&((p->y)<538))
		(*c)=5;
	}
if(strcmp(ch,"return")==0)
(*c)=(*f);
if(strcmp(ch,"down")==0)
	{Mix_PlayMusic(musics,1);
	if((*f)==5)
		(*f)=0;
	else (*f)++;
	}
if(strcmp(ch,"up")==0)
	{Mix_PlayMusic(musics,1);
	if((*f)==0)
		(*f)=5;
	else (*f)--;
	}
}

