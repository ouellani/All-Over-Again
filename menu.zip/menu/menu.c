#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "SDL/SDL.h"
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_image.h>
#include "init.h"
#include "update.h"
#include "display.h"
#include "input.h"
#include "struct.h"
int main()
{SDL_Surface *screen=NULL;
SDL_Surface *bg=NULL;
SDL_Surface *button1[6],*button2[6];
SDL_Rect positionbg,positionbutton[6];
SDL_Event event;
Mix_Music *musicl=NULL,*musics=NULL;
pos p;
char ch[4];
int continuer=1,i,f=0,c=-1,etat=1;
init_buttons(button1,positionbutton,button2);
init_bg(&bg,&positionbg);
SDL_Init(SDL_INIT_VIDEO);
screen=SDL_SetVideoMode(800,600,32,SDL_SWSURFACE|SDL_RESIZABLE|SDL_DOUBLEBUF);
Mix_OpenAudio(44100,MIX_DEFAULT_FORMAT,2,1024);
musicl=Mix_LoadMUS("menu_sound.mp3");
Mix_PlayMusic(musicl,-1);
SDL_EnableKeyRepeat(30,30);
while(continuer==1)
{SDL_PollEvent(&event);
aff(f,&screen,bg,button1,button2,positionbg,positionbutton,c);
SDL_Flip(screen);
SDL_PollEvent(&event);
input_t(event,ch,&p);
if(strcmp(ch,"exit")==0)
continuer=0;
choix(&f,&c,event,ch,&p,musics);
strcpy(ch,"");
SDL_Delay(35);
if(c==5)
{continuer=0;
}
if(c==4)
{ if(Mix_PausedMusic() == 1)
                    {
                        Mix_ResumeMusic(); 
			c=-1;
                    }
                    else
                    {
                        Mix_PauseMusic();
			c=-1;
			}
}
}
for(i=0;i<6;i++)
{SDL_FreeSurface(button1[i]);
SDL_FreeSurface(button2[i]);}
Mix_FreeMusic(musicl);
Mix_CloseAudio();
SDL_FreeSurface(bg);
SDL_Quit();
}

