#ifndef STRUCT_H_
#define STRUCT_H_
typedef struct pos
{int x;
int y;
}pos;
#endif /* FONCTIONS_H_ */
