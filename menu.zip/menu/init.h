#ifndef INIT_H_
#define INIT_H_

void init_buttons(SDL_Surface *button1[4],SDL_Rect positionbutton[4],SDL_Surface *button2[4]);
void init_bg(SDL_Surface **bg,SDL_Rect *positionbg);
#endif /* FONCTIONS_H_ */
