#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "SDL/SDL.h"
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_image.h>
#include "input.h"
#include "struct.h"
void input_t(SDL_Event event,char ch[10],pos *p)
{SDL_PollEvent(&event);
switch(event.type)
	{case SDL_QUIT:strcpy(ch,"exit");break;
	case SDL_KEYDOWN:
		{switch(event.key.keysym.sym)

                	{

                   	 case SDLK_UP:

                        	strcpy(ch,"up");

                        	break;

                    	case SDLK_DOWN:

                        strcpy(ch,"down");

                        break;

                    	case SDLK_RIGHT:

                        strcpy(ch,"right");

                        break;

                    	case SDLK_LEFT:

                        strcpy(ch,"left");

                        break;
		    	case SDLK_RETURN:
			
			strcpy(ch,"return");break;
               		 }

                
		}break;
	case SDL_MOUSEBUTTONDOWN:
		{
			if (event.button.button == SDL_BUTTON_LEFT)
				{strcpy(ch,"cg");
				p->x=event.button.x;
				p->y=event.button.y;}
		}break;
	case SDL_MOUSEMOTION:
			{strcpy(ch,"mm");
			p->x=event.motion.x;
			p->y=event.motion.y;
			
	}break;
}
}

