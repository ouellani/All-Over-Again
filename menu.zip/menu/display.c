#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "SDL/SDL.h"
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_image.h>
#include "display.h"
#include "struct.h"
void aff(int f,SDL_Surface **screen,SDL_Surface *bg,SDL_Surface *button1[6],SDL_Surface *button2[6],
SDL_Rect positionbg,SDL_Rect positionbutton[6],int c)
{int i;
if ((c!=0)&&(c!=2))
{SDL_BlitSurface(bg,NULL,*screen,&positionbg);
for(i=0;i<6;i++)
{if(f==i)
	{
	SDL_SetColorKey(button2[i], SDL_SRCCOLORKEY, SDL_MapRGB(button2[i]->format,0,0,0));
	SDL_BlitSurface(button2[i],NULL,(*screen),&positionbutton[i]);		
	}
else
	{SDL_SetColorKey(button1[i], SDL_SRCCOLORKEY, SDL_MapRGB(button1[i]->format,0,0,0));
	SDL_BlitSurface(button1[i],NULL,(*screen),&positionbutton[i]);
	}
}
}
else if((c==0)||(c==1))
SDL_FillRect((*screen), NULL, SDL_MapRGB((*screen)->format,0,0,0));
else 
SDL_FillRect((*screen), NULL, SDL_MapRGB((*screen)->format,0,0,0));
}
