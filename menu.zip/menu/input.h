#ifndef INPUT_H_
#define INPUT_H_
#include "struct.h"
void input_t(SDL_Event event,char ch[10],pos *p);
#endif /* FONCTIONS_H_ */
