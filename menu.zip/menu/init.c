#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "SDL/SDL.h"
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_image.h>
#include "init.h"
#include "struct.h"
void init_buttons(SDL_Surface *button1[4],SDL_Rect positionbutton[4],SDL_Surface *button2[4])
{
positionbutton[0].x=260;
positionbutton[0].y=50;
positionbutton[1].x=260;
positionbutton[1].y=130;
positionbutton[2].x=260;
positionbutton[2].y=210;
positionbutton[3].x=260;
positionbutton[3].y=290;
positionbutton[4].x=260;
positionbutton[4].y=370;
positionbutton[5].x=260;
positionbutton[5].y=420;
button1[0]=SDL_LoadBMP("play1.bmp");
button1[1]=SDL_LoadBMP("credits1.bmp");
button1[2]=SDL_LoadBMP("settings1.bmp");
button1[3]=SDL_LoadBMP("score1.bmp");
button1[4]=SDL_LoadBMP("music1.bmp");
button1[5]=SDL_LoadBMP("exit1.bmp");
button2[0]=SDL_LoadBMP("play2.bmp");
button2[1]=SDL_LoadBMP("credits2.bmp");
button2[2]=SDL_LoadBMP("settings2.bmp");
button2[3]=SDL_LoadBMP("score2.bmp");
button2[4]=SDL_LoadBMP("music2.bmp");
button2[5]=SDL_LoadBMP("exit2.bmp");
}
void init_bg(SDL_Surface **bg,SDL_Rect *positionbg)
{positionbg->x=0;
positionbg->y=0;
(*bg)=SDL_LoadBMP("menu.bmp");
}
