#ifndef DISPLAY_H_
#define DISPLAY_H_
void aff(int f,SDL_Surface **screen,SDL_Surface *bg,SDL_Surface *button1[5],SDL_Surface *button2[5],SDL_Rect positionbg,SDL_Rect positionbutton[5],int c);
#endif /* FONCTIONS_H_ */
