#ifndef UPDATE_H_
#define UPDATE_H_
#include "struct.h"
void choix(int *f,int *c,SDL_Event event,char ch[10],pos *p,Mix_Music *musics);
#endif /* FONCTIONS_H_ */
